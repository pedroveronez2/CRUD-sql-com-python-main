# CRUD sql com python
 esse é um pequeno codigo python com sql 

 Importante voce ter pycharm ou visual stude,  python 3 instalados